package es.ibermatica.beans;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.model.SelectItem;
import javax.faces.model.SelectItemGroup;


@ManagedBean
public class DatosBean implements Serializable{
	
	private Date entrada;
	private Date salida;
	private String nombre;
	private String apellido;
	private String sexo;
	private String nivelEstudios;
	private List<String> idiomas;
	private String[] idiomasSeleccionados;
	
	@PostConstruct
    public void init() {
		idiomas = new ArrayList<>();
		idiomas.add("Español");
		idiomas.add("Ingles");
		idiomas.add("Frances");
		idiomas.add("Aleman");
		idiomas.add("Chino");
		idiomas.add("Arabe");
		idiomas.add("Pakistani");
		idiomas.add("Ruso");
		idiomas.add("Polaco");
	}
	
	public List<SelectItem> estudios() {
		
		List<SelectItem> lista = new ArrayList<>();

        SelectItemGroup estudiosElementales = new SelectItemGroup("Estudios Elementales");
        estudiosElementales.setSelectItems(new SelectItem[]{
            new SelectItem("Primaria", "Primaria"),
            new SelectItem("Secundaria", "Secundaria"),
            new SelectItem("Bachillerato", "Bachillerato")
        });

        SelectItemGroup estudiosAvanzados = new SelectItemGroup("Estudios Avanzados");
        estudiosAvanzados.setSelectItems(new SelectItem[]{
            new SelectItem("Grado Medio", "Grado Medio"),
            new SelectItem("Grado Superior", "Grado Superior"),
            new SelectItem("Grado Universitario", "Grado Universitario"),
            new SelectItem("Master", "Master"),
            new SelectItem("Doctorado", "Doctorado")
        });

        lista.add(estudiosElementales);
        lista.add(estudiosAvanzados);
        
        return lista;
	}
	

	
	
	public Date getEntrada() {
		return entrada;
	}

	public void setEntrada(Date entrada) {
		this.entrada = entrada;
	}

	public Date getSalida() {
		return salida;
	}

	public void setSalida(Date salida) {
		this.salida = salida;
	}

	public String getNombre() {
		return nombre;
	}
	
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public String getSexo() {
		return sexo;
	}
	
	public void setSexo(String sexo) {
		this.sexo = sexo;
	}

	public String getNivelEstudios() {
		return nivelEstudios;
	}


	public void setNivelEstudios(String nivelEstudios) {
		this.nivelEstudios = nivelEstudios;
	}


	public List<String> getIdiomas() {
		return idiomas;
	}


	public void setIdiomas(List<String> idiomas) {
		this.idiomas = idiomas;
	}

	public String[] getIdiomasSeleccionados() {
		return idiomasSeleccionados;
	}

	public void setIdiomasSeleccionados(String[] idiomasSeleccionados) {
		this.idiomasSeleccionados = idiomasSeleccionados;
	}
	
	
	

}
