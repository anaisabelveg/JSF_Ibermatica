package es.ibermatica.beans;

import java.util.List;

import javax.faces.bean.ManagedBean;

import es.ibermatica.models.Producto;
import es.ibermatica.persistence.ProductosDAO;

// Si no le pongo nombre coge el nombre de la clase, la primera letra en minuscula
@ManagedBean
public class ProductosBean {
	
	private Producto producto = new Producto();
	
	// Metodo de accion
	public List<Producto> consultarTodos(){
		ProductosDAO dao = new ProductosDAO();
		return dao.todos();
	}
	
	
	// Metodo de navegacion -> devuelve el nombre de la vista
	public String altaProducto() {
		ProductosDAO dao = new ProductosDAO();
		dao.alta(producto);
		return "mostrarMensaje";
	}
	
	public Producto getProducto() {
		return producto;
	}
	
	public void setProducto(Producto producto) {
		this.producto = producto;
	}
	
}
