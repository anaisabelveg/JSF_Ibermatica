package es.ibermatica.persistence;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.faces.bean.ApplicationScoped;
import javax.faces.bean.ManagedBean;

import es.ibermatica.models.Producto;

// eager = true; forzamos la creacion del bean en el momento de arrancar la aplicacion
// si no pusiesemos (eager=false) el bean se crearia la primera vez que se solicita
@ManagedBean(name = "dao", eager = true)
@ApplicationScoped
public class ProductosDAO {
	
	@PostConstruct
	public void init() {
		System.out.println("El bean dao se ha creado");
	}
	
	@PreDestroy
	public void destroy() {
		System.out.println("El bean dao se va a destruir");
	}
	
	public List<Producto> todos(){
		
		List<Producto> lista = new ArrayList<Producto>();
		
		for(int i=1; i<=10; i++) {
			lista.add(new Producto(i, "Producto "+i, i*100));
		}
		
		return lista;
	}
	
	public Producto buscar(int id) {
		return new Producto(id, "Producto "+id, id*100);
	}
	
	public boolean alta(Producto nuevo) {
		// ......
		return true;
	}
}
