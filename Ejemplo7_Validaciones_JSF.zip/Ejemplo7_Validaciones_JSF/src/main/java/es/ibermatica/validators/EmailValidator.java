package es.ibermatica.validators;

import java.util.ResourceBundle;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.FacesValidator;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;

@FacesValidator(value = "emailValidator")
public class EmailValidator implements Validator{

	@Override
	public void validate(FacesContext context, UIComponent component, Object value) throws ValidatorException {
		
		// Recoger el valor y convertirlo a un String
		String email = (String) value;
		
		// Voy a comprobar si tiene una '@' para ser valido
		if (email.indexOf("@") == -1) {
			throw new ValidatorException(new FacesMessage("Email no valido"));
		}
		
		// Como puedo mostrar el mensaje de error del archivo de propiedades, en su idioma correspondiente
		/*ResourceBundle rb = ResourceBundle.getBundle("errores_msg", context.getViewRoot().getLocale());
		
		if (email.indexOf("@") == -1) {
			throw new ValidatorException(new FacesMessage(rb.getString("error.mail")));
		}
		*/
		
	}

}
