package es.ibermatica.beans;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;


@ManagedBean
@SessionScoped
public class DatosBean implements Serializable{
	
	private List<Producto> productos;
	
	@PostConstruct
	public void init() {
		
		productos = new ArrayList<Producto>();
		
		for(int i=1; i<= 50; i++) {
			int numero = (int) (Math.random() * 100);
			productos.add(new Producto(numero, "Producto " + numero, numero * 100));
		}
	}
	
	public List<Producto> getProductos(){
		return productos;
	}
	
	public void setProductos(List<Producto> productos) {
		this.productos = productos;
	}
	
	

}
