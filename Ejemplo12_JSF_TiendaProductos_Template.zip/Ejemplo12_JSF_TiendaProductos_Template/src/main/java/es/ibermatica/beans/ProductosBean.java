package es.ibermatica.beans;

import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.RequestScoped;

import es.ibermatica.models.Producto;
import es.ibermatica.persistence.ProductosDAO;


@ManagedBean
@RequestScoped
public class ProductosBean {
	
	private Producto producto = new Producto();
	
	// Inyectamos el bean dao en la propiedad productosDAO
	// Para que JSF pueda inyectar la propiedad, necesita get y set
	@ManagedProperty(value = "#{dao}")
	private ProductosDAO productosDAO;
	
	// Metodo de accion
	public List<Producto> consultarTodos(){
		//ProductosDAO dao = new ProductosDAO();
		return productosDAO.todos();
	}
	
	
	// Metodo de navegacion -> devuelve el nombre de la vista
	public String altaProducto() {
		//ProductosDAO dao = new ProductosDAO();
		productosDAO.alta(producto);
		return "mostrarMensaje";
	}
	
	public Producto getProducto() {
		return producto;
	}
	
	public void setProducto(Producto producto) {
		this.producto = producto;
	}


	public ProductosDAO getProductosDAO() {
		return productosDAO;
	}


	public void setProductosDAO(ProductosDAO productosDAO) {
		this.productosDAO = productosDAO;
	}
	
	
	
}
