package es.ibermatica.beans;

import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.model.SelectItem;


@ManagedBean
public class ProvinciasBean {
	
	private int id;
	
	public List<SelectItem> getProvincias(){
		List<SelectItem> lista = new ArrayList<SelectItem>();
		lista.add(new SelectItem("-- Seleccione provincia --"));
		lista.add(new SelectItem(1, "Madrid"));
		lista.add(new SelectItem(2, "Valladolid"));
		return lista;
	}
	
	public List<SelectItem> getLocalidades(){
		List<SelectItem> lista = new ArrayList<SelectItem>();
		lista.add(new SelectItem("-- Seleccione localidad --"));
		
		switch (id) {
			case 1:
				lista.add(new SelectItem(1, "Alcorcon"));
				lista.add(new SelectItem(2, "Getafe"));
				lista.add(new SelectItem(3, "Alcala de Henares"));
				lista.add(new SelectItem(4, "Las Rozas"));
				break;
	
			case 2:
				lista.add(new SelectItem(1, "Boecillo"));
				lista.add(new SelectItem(2, "Tordesillas"));
				lista.add(new SelectItem(3, "Rueda"));
				lista.add(new SelectItem(4, "Medina del Campo"));
				break;
		}
		
		return lista;
	}
	
	public int getId() {
		return id;
	}
	
	public void setId(int id) {
		this.id = id;
	}
}
