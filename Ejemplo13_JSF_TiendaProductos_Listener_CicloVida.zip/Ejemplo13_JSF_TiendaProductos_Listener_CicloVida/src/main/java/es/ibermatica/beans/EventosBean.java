package es.ibermatica.beans;

import javax.faces.bean.ApplicationScoped;
import javax.faces.bean.ManagedBean;

@ManagedBean(name = "eventos")
@ApplicationScoped
public class EventosBean {
	
	public void antesRenderizarComponente() {
		System.out.println("Se va a renderizar el componente");
	}
	
	public void antesRenderizarVista() {
		System.out.println("Se va a renderizar la vista");
	}
	
	public void antesValidacion() {
		System.out.println("Se va a proceder a la validacion");
	}
	
	public void despuesValidacion() {
		System.out.println("Se ha validado el componente");
	}

}
