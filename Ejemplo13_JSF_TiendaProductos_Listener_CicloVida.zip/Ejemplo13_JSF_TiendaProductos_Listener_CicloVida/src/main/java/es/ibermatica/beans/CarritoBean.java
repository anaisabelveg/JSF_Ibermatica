package es.ibermatica.beans;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.SessionScoped;

import es.ibermatica.models.Producto;
import es.ibermatica.persistence.ProductosDAO;

@ManagedBean(name = "carrito")
@SessionScoped
public class CarritoBean implements Serializable{
	

	/**
	 * 
	 */
	private static final long serialVersionUID = 5457537871089192181L;
	
	private List<Producto> contenido = new ArrayList<Producto>();
	private double importe;
	
	@ManagedProperty(value = "#{dao}")
	private ProductosDAO productosDAO;
	
	
	public String agregarProducto(int id) {
		//ProductosDAO dao = new ProductosDAO();
		Producto encontrado = productosDAO.buscar(id);
		contenido.add(encontrado);
		importe += encontrado.getPrecio();
		return "mostrarCarrito";
	}
	
	public String sacarProducto(int id) {
		Producto eliminar = null;
		for (Producto producto : contenido) {
			if (id == producto.getId()) {
				eliminar = producto;
				break;
			}
		}
		contenido.remove(eliminar);
		importe -= eliminar.getPrecio();
		return "mostrarCarrito";
	}
	
	
	
	public List<Producto> getContenido() {
		return contenido;
	}
	public void setContenido(List<Producto> contenido) {
		this.contenido = contenido;
	}
	public double getImporte() {
		return importe;
	}
	public void setImporte(double importe) {
		this.importe = importe;
	}

	public ProductosDAO getProductosDAO() {
		return productosDAO;
	}

	public void setProductosDAO(ProductosDAO productosDAO) {
		this.productosDAO = productosDAO;
	}
	
	
	

}
