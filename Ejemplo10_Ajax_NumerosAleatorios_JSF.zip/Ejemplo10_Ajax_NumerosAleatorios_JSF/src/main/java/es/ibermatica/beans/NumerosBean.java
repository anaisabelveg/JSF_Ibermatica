package es.ibermatica.beans;

import javax.faces.bean.ManagedBean;

@ManagedBean
public class NumerosBean {
	
	private double numero;
	
	public void generar() {
		// Generar un numero aleatorio entre 0 y 100
		numero = Math.random() * 100;
	}
	
	public double getNumero() {
		return numero;
	}
	
	public void setNumero(double numero) {
		this.numero = numero;
	}
	

}
