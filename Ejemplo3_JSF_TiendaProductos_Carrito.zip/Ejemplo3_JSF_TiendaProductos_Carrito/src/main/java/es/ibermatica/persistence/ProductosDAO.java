package es.ibermatica.persistence;

import java.util.ArrayList;
import java.util.List;

import es.ibermatica.models.Producto;

public class ProductosDAO {
	
	public List<Producto> todos(){
		
		List<Producto> lista = new ArrayList<Producto>();
		
		for(int i=1; i<=10; i++) {
			lista.add(new Producto(i, "Producto "+i, i*100));
		}
		
		return lista;
	}
	
	public Producto buscar(int id) {
		return new Producto(id, "Producto "+id, id*100);
	}
	
	public boolean alta(Producto nuevo) {
		// ......
		return true;
	}
}
