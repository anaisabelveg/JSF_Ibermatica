package es.ibermatica.converters;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

import es.ibermatica.utils.EstadoCivil;

@FacesConverter(value = "estadoCivilConverter")
public class EstadoCivilConverter implements Converter{

	@Override
	public Object getAsObject(FacesContext context, UIComponent component, String value) {
		
		return EstadoCivil.valueOf(value);
	}

	@Override
	public String getAsString(FacesContext context, UIComponent component, Object value) {
		
		String estado = (String) value;
		return estado;
	}

}
