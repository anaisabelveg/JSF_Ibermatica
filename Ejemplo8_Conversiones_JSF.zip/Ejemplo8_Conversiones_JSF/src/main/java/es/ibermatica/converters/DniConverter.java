package es.ibermatica.converters;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

import es.ibermatica.beans.DNI;

@FacesConverter(value = "dniConverter")
public class DniConverter implements Converter{

	@Override
	public Object getAsObject(FacesContext context, UIComponent component, String value) {
		// Recoger datos de la vista y procesarlo en el managedBean como objetos
		
		// Recibimos el dni como un String y lo queremos devolver como una instancia DNI
		return new DNI(value);
	}

	@Override
	public String getAsString(FacesContext context, UIComponent component, Object value) {
		// Los datos del managedBean los representamos como String en la vista
		
		// El objeto DNI lo convierto en un String
		DNI object = (DNI) value;
		return object.toString();
	}

}
