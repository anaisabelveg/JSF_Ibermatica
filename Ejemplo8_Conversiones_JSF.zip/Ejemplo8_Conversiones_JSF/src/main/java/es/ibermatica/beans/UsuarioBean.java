package es.ibermatica.beans;

import java.util.Date;
import java.util.GregorianCalendar;

import javax.faces.bean.ManagedBean;

@ManagedBean(name = "usuario")
public class UsuarioBean {

	private Date fecha = new GregorianCalendar().getTime();
	private Number numero = 15.75;
	private DNI dni;

	public Date getFecha() {
		return fecha;
	}

	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}

	public Number getNumero() {
		return numero;
	}

	public void setNumero(Number numero) {
		this.numero = numero;
	}

	public DNI getDni() {
		return dni;
	}

	public void setDni(DNI dni) {
		this.dni = dni;
	}

}
