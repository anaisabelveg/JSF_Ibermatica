package es.ibermatica.beans;

public class DNI {
	
	private String dni;
	
	public DNI() {
		// TODO Auto-generated constructor stub
	}

	public DNI(String dni) {
		super();
		this.dni = dni;
	}

	public String getDni() {
		return dni;
	}

	public void setDni(String dni) {
		this.dni = dni;
	}

	@Override
	public String toString() {
		return "DNI [dni=" + dni + "]";
	}
	
	

}
