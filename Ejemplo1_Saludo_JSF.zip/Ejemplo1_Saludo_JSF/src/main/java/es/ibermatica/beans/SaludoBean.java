package es.ibermatica.beans;

import javax.faces.bean.ManagedBean;

// Si no le pongo nombre coge el nombre de la clase, la primera letra en minuscula
@ManagedBean(name = "saludo")
public class SaludoBean {
	
	private String nombre = "Introduce tu nombre";
	
	public String getNombre() {
		return nombre;
	}
	
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

}
